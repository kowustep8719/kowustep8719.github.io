import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from
'../services/authentication.service';
@Component({
// Define the selector, template file and CSS styles for the component
selector: 'app-navbar',
templateUrl: './navbar.component.html',
styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
constructor(
// Dependency injection for AuthenticationService
 private authenticationService: AuthenticationService
) { }
// Lifecycle hook called after component initialization
ngOnInit() { }
// Method to check if the user is logged in
public isLoggedIn(): boolean {
 return this.authenticationService.isLoggedIn();
}
// Method to handle user logout
private onLogout(): void {
 return this.authenticationService.logout();
}
}