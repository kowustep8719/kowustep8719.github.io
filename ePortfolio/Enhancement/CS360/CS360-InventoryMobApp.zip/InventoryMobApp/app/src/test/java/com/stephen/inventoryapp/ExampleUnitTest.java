// Stephen Inventory Mobile App

package com.stephen.inventoryapp;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 * <p>
 * '@check' <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    // Annotate the following method as a test case
    @Test
    public void addition_isCorrect() {
        // Assert that the addition of 2 + 2 equals 4
        assertEquals(4, 2 + 2);
    }
}